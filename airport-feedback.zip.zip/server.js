import express from "express";
import cors from "cors";
import mongoose from "mongoose";
const app = express();

app.use(cors());
app.use(express.json());

mongoose
  .connect("mongodb+srv://nitikaa2006_db_user:niti1812@airportsurveydb.4240rjb.mongodb.net/?appName=AirportSurveyDB")
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log(err));

const SurveySchema = new mongoose.Schema({
  airportName: String,
  airportCode: String,
  tripReason: String,
  travelClass: String,
  returnTrips: String,

  ratings: {
    q1: Number,
    q2: Number,
    q3: Number,
    q4: Number,
    q5: Number,
    q6: Number,
    q7: Number,
  },

  comments: String,
  submittedAt: String,
});

const Survey = mongoose.model("Survey", SurveySchema);

app.get("/", (req, res) => {
  res.send("Backend Running Successfully");
});
const submittedUsers = new Set();
app.post("/submitSurvey", async (req, res) => {
  const userIP = req.ip;
  console.log("Current IP:", userIP);

//if (submittedUsers.has(userIP)) {
  //return res.status(400).json({
    //message:
      //"You have already submitted feedback.",
 // });

  try {
    const survey = new Survey(req.body);
    await survey.save();
    //submittedUsers.add(userIP);
    console.log(submittedUsers);
    res.json({
      message: "Survey Saved Successfully",
      
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      message: "Error Saving Survey",
    });
  }
});
app.get("/surveys", async (req, res) => {
  try {
    const surveys = await Survey.find();
    res.json(surveys);
  } catch (error) {
    res.status(500).json({
      message: "Error Fetching Surveys",
    });
  }
});
app.listen(5000, () => {
  console.log("Server running on port 5000");
});